import { useState } from 'react'
import './App.css'
import { EmailLoginBtn } from './components/EmailLoginBtn'

function App() {

  return (
    <>
    <EmailLoginBtn />
    </>
  )
}

export default App
