import React, { useState } from 'react';

export const PasswordBtn = () => {
  const [password, setPassword] = useState('');

  const handleInputChange = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = () => {
    // Aquí puedes usar el valor de 'email' para realizar alguna acción, como iniciar sesión.
    console.log('Password:', password);
  };

  return (
    <>
      <label>Password: <input type="email" onChange={handleInputChange} /></label><br />
      <button onClick={handleLogin}>LOG IN</button>
    </>
  );
};
