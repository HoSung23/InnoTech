import React, { useState } from 'react';

export const EmailLoginBtn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleInputChange = (e) => {
    setEmail(e.target.value);
  };

  const handleInputChangeP = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = () => {
    // Aquí puedes usar el valor de 'email' para realizar alguna acción, como iniciar sesión.
    console.log('Email ingresado:', email);
  };

  const handleLoginP = () => {
    // Aquí puedes usar el valor de 'password' para realizar alguna acción.
    console.log('Password:', password);
  };

  const handleLoginClick = () => {
    handleLogin();
    handleLoginP();
  };

  return (
    <>
      <label>Email: <input type="email" onChange={handleInputChange} /></label><br />
      <label>Password: <input type="password" onChange={handleInputChangeP} /></label>
      <button onClick={handleLoginClick}>LOG IN</button>
    </>
  );
};
